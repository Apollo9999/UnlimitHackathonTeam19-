from django.shortcuts import render
from .forms import InventoryForm
from .models import Inventory

# Create your views here.
def index(request):
    form = InventoryForm(request.POST or None)
    if form.is_valid():
        form.save()
    cont = {
        'form':form}     
    return render(request,"index.html",cont)