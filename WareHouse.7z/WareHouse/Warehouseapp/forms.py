from django import forms
from .models import Inventory

class InventoryForm(forms.ModelForm):
    class Meta:
        model = Inventory
        fields = ["rf_id",
                  "stack_id",
                  "sid_column",
                  "sid_row",
                  "f_address",
                  "p_address",
                  "s_range",
                  "e_range"]
