from django.apps import AppConfig


class WarehouseappConfig(AppConfig):
    name = 'Warehouseapp'
