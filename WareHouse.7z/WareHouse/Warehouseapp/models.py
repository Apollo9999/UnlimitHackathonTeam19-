from django.db import models

# Create your models here.
class Inventory(models.Model):
    package_id = models.AutoField(primary_key = True)
    rf_id = models.CharField(max_length = 50,unique = True)
    stack_id = models.CharField(max_length = 50,unique = True)
    sid_column = models.CharField(max_length = 50)
    sid_row = models.CharField(max_length = 50)
    f_address = models.TextField(max_length = 250)
    p_address = models.TextField(max_length = 250)
    s_range = models.CharField(max_length = 50)
    e_range = models.CharField(max_length = 50)
    

    